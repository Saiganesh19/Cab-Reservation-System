package cts.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


import cts.models.User;
import cts.service.LoginService;

@Controller
public class LoginController {
	
	@Autowired
	private LoginService service;
	
	@GetMapping("/welcome")
	public String welcome() {
		return "welcome";
	}
	
	@GetMapping("/register")
	public String register() {
		return "register";
	}
	
	@PostMapping("/registration")
	public String register( @ModelAttribute User user, Model model)
	{
		
		if( service.createNewUser(user))
		{
			model.addAttribute("message", "Account Created Successfully");
		}
		
		return "Login";
	}
	
	@GetMapping("/index")
	public String showLogin() {
		return "Login";
	}
	
	
	@PostMapping("/home")
	public String isValid(@RequestParam("username") String username, @RequestParam("password") String password, Model m) {
		if(service.isValidLogin(username, password))
		{
			
			m.addAttribute("username", username);
			return "home";
		}
		else
		{
			m.addAttribute("errMsg", "Invalid Username or password");
		return "Login";
		
		}
	}

}
