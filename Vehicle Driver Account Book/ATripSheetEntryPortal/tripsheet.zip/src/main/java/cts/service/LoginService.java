package cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import cts.models.User;
import cts.proxy.LoginProxy;



@Service
public class LoginService {
	
	@Autowired
	private LoginProxy proxy;
	
	public boolean createNewUser(User user) {
		ResponseEntity<User> userresp=proxy.create(user);
		
		if(userresp.getStatusCode().value() == 201)
			return true;

				
				return  false;
	}
     
	
	public boolean isValidLogin(String username, String password)
	{
	     ResponseEntity<User> resp=	proxy.getUserByUserName(username);
	      User user =resp.getBody();			 
			  if(user.getPassword().equals(password)) 
			  {
				  return true;
			  } 
		return false;	  
	}
}
